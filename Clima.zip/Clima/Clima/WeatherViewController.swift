import UIKit
import CoreLocation
import Alamofire
import SwiftyJSON

class WeatherViewController: UIViewController, CLLocationManagerDelegate, ChangeCityDelegate {
    
    let WEATHER_URL = "http://api.openweathermap.org/data/2.5/forecast"
    let APP_ID = "2040e2cd56ab6f5c7f39e98126652599"
    
    //TODO: Declare instance variables here
    let locationManager = CLLocationManager()
    let weatherDataModel = WeatherDataModel()
    
    @IBOutlet weak var cityLabel: UILabel!

    @IBOutlet weak var dateLbl1: UILabel!
    @IBOutlet weak var tempLbl1: UILabel!
    @IBOutlet weak var dateLbl2: UILabel!
    @IBOutlet weak var tempLbl2: UILabel!
    @IBOutlet weak var dateLbl3: UILabel!
    @IBOutlet weak var tempLbl3: UILabel!
    @IBOutlet weak var dateLbl4: UILabel!
    @IBOutlet weak var tempLbl4: UILabel!
    @IBOutlet weak var dateLbl5: UILabel!
    @IBOutlet weak var tempLbl5: UILabel!
    
    
    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var image2: UIImageView!
    @IBOutlet weak var image3: UIImageView!
    @IBOutlet weak var image4: UIImageView!
    @IBOutlet weak var image5: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    func getWeatherData(url: String, parameters: [String: String]) {
        Alamofire.request(url, method: .get, parameters: parameters).responseJSON {
            response in
            if response.result.isSuccess {
                print("Success! Got the weather data")
                
                let weatherJSON : JSON = JSON(response.result.value!)
                //print(weatherJSON)
                self.updateWeatherData(json: weatherJSON)
                
            } else {
                print("Error \(response.result.error)")
                self.cityLabel.text = "Connection Issue"
            }
        }
    }

    func updateWeatherData(json: JSON) {
       
    //check on API returned result
    //        for i in 0...30 {
    //
    //
    //            if (i==0 || i==6 || i==14 || i==22 || i==30)
    //                {
    //                    weatherDataModel.city = json["city"]["name"].stringValue
    //                    print(weatherDataModel.city)
    //                    weatherDataModel.date = json["list"][i]["dt_txt"].stringValue
    //                    print(weatherDataModel.date)
    //                    weatherDataModel.temperature = json["list"][i]["main"]["temp"].doubleValue - 273.15
    //                    let formatted = String(format: "%.2f", weatherDataModel.temperature)
    //                    print(formatted)
    //            }
    //        }
        
            if let weather = json["city"]["name"].string {
                    cityLabel.text = weather
                    //update date Labels
                    let temp1 = json["list"][0]["dt_txt"].stringValue
                    let getDate1 = temp1.index(temp1.startIndex, offsetBy: 10)
                    let date1: String = String(temp1[..<getDate1])
                    dateLbl1.text = date1
                
                    let temp2 = json["list"][6]["dt_txt"].stringValue
                    let getDate2 = temp2.index(temp2.startIndex, offsetBy: 10)
                    let date2: String = String(temp2[..<getDate2])
                    dateLbl2.text = date2
                
                    let temp3 = json["list"][14]["dt_txt"].stringValue
                    let getDate3 = temp3.index(temp3.startIndex, offsetBy: 10)
                    let date3: String = String(temp3[..<getDate3])
                    dateLbl3.text = date3
                
                    let temp4 = json["list"][22]["dt_txt"].stringValue
                    let getDate4 = temp4.index(temp4.startIndex, offsetBy: 10)
                    let date4: String = String(temp4[..<getDate4])
                    dateLbl4.text = date4
                
                    let temp5 = json["list"][30]["dt_txt"].stringValue
                    let getDate5 = temp5.index(temp5.startIndex, offsetBy: 10)
                    let date5: String = String(temp5[..<getDate5])
                    dateLbl5.text = date5
                
                    //update temperature labels
                    weatherDataModel.temperature = json["list"][0]["main"]["temp"].doubleValue - 273.15
                    tempLbl1.text = String(format:"%.1f", weatherDataModel.temperature)
                    weatherDataModel.temperature = json["list"][6]["main"]["temp"].doubleValue - 273.15
                    tempLbl2.text = String(format:"%.1f", weatherDataModel.temperature)
                    weatherDataModel.temperature = json["list"][14]["main"]["temp"].doubleValue - 273.15
                    tempLbl3.text = String(format:"%.1f", weatherDataModel.temperature)
                    weatherDataModel.temperature = json["list"][22]["main"]["temp"].doubleValue - 273.15
                    tempLbl4.text = String(format:"%.1f", weatherDataModel.temperature)
                    weatherDataModel.temperature = json["list"][30]["main"]["temp"].doubleValue - 273.15
                    tempLbl5.text = String(format:"%.1f", weatherDataModel.temperature)
                
                    weatherDataModel.condition = json["list"][0]["weather"][0]["id"].intValue
                    weatherDataModel.weatherIconName = weatherDataModel.updateWeatherIcon(condition: weatherDataModel.condition)
                    image1.image = UIImage(named: weatherDataModel.weatherIconName)
                    weatherDataModel.condition = json["list"][6]["weather"][0]["id"].intValue
                    weatherDataModel.weatherIconName = weatherDataModel.updateWeatherIcon(condition: weatherDataModel.condition)
                    image2.image = UIImage(named: weatherDataModel.weatherIconName)
                    weatherDataModel.condition = json["list"][14]["weather"][0]["id"].intValue
                    weatherDataModel.weatherIconName = weatherDataModel.updateWeatherIcon(condition: weatherDataModel.condition)
                    image3.image = UIImage(named: weatherDataModel.weatherIconName)
                    weatherDataModel.condition = json["list"][22]["weather"][0]["id"].intValue
                    weatherDataModel.weatherIconName = weatherDataModel.updateWeatherIcon(condition: weatherDataModel.condition)
                    image4.image = UIImage(named: weatherDataModel.weatherIconName)
                    weatherDataModel.condition = json["list"][30]["weather"][0]["id"].intValue
                    weatherDataModel.weatherIconName = weatherDataModel.updateWeatherIcon(condition: weatherDataModel.condition)
                    image5.image = UIImage(named: weatherDataModel.weatherIconName)
                
                
            } else {
                cityLabel.text = "Weather Unavailable"
            }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[locations.count - 1]
        if location.horizontalAccuracy > 0 {
            locationManager.stopUpdatingLocation()
            locationManager.delegate = nil
            print("longitude = \(location.coordinate.longitude), latitude = \(location.coordinate.latitude)")
            let longitude = String(location.coordinate.longitude)
            let latitute = String(location.coordinate.latitude)
            
            let params : [String : String] = ["lat" : latitute, "lon" : longitude, "appid" : APP_ID]
            getWeatherData(url: WEATHER_URL, parameters: params)
        }
    }
    
    
    //didFailWithError message here:
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
        cityLabel.text = "Location Unavailable"
    }
    
    // userEnteredANewCityName Delegate method here:
    func userEnteredANewCityName(city: String) {
        let params : [String : String] = ["q" : city, "appid" : APP_ID]
        getWeatherData(url: WEATHER_URL, parameters: params)
    }

    //PrepareForSegue Method here
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "changeCityName" {
            let destinationVC = segue.destination as! ChangeCityViewController
            destinationVC.delegate = self
        }
    }
    
}


